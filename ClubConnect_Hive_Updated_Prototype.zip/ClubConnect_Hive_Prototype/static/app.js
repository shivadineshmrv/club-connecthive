document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll('input[type="date"]').forEach(input => {
    if (!input.min) input.min = new Date().toISOString().slice(0,10);
  });
  document.querySelectorAll('select[multiple]').forEach(select => {
    select.addEventListener('change', () => select.classList.toggle('has-selection', select.selectedOptions.length >= 2));
  });
});
