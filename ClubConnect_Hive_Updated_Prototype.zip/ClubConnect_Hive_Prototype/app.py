from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3, os
from contextlib import contextmanager
from datetime import datetime

app = Flask(__name__)
app.secret_key = "clubconnect-demo-key"
DB_PATH = os.path.join(os.path.dirname(__file__), "clubconnect.db")

@contextmanager
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS clubs(id INTEGER PRIMARY KEY, name TEXT UNIQUE, category TEXT, icon TEXT, description TEXT, advisor TEXT, president TEXT, achievements TEXT);
        CREATE TABLE IF NOT EXISTS members(id INTEGER PRIMARY KEY, name TEXT, email TEXT, club_id INTEGER, role TEXT DEFAULT 'Member', UNIQUE(email,club_id));
        CREATE TABLE IF NOT EXISTS resources(id INTEGER PRIMARY KEY, name TEXT UNIQUE, kind TEXT, capacity INTEGER);
        CREATE TABLE IF NOT EXISTS bookings(id INTEGER PRIMARY KEY, resource_id INTEGER, club_id INTEGER, title TEXT, booking_date TEXT, start_time TEXT, end_time TEXT, status TEXT DEFAULT 'Approved', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, title TEXT, description TEXT, event_date TEXT, start_time TEXT, venue TEXT, club_ids TEXT, status TEXT DEFAULT 'Published');
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, author TEXT, body TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY, event_id INTEGER, student_name TEXT, checked_at TEXT DEFAULT CURRENT_TIMESTAMP);
        """)
        if c.execute("SELECT COUNT(*) FROM clubs").fetchone()[0] == 0:
            clubs = [
                ("ACM Student Chapter","Technical","⌘","Coding, algorithms, developer talks and peer learning.","Dr. Ananya Rao","Arjun Kumar","Won inter-college coding sprint 2025"),
                ("Robotics Club","Technical","🤖","Build intelligent machines through embedded systems, automation and robotics.","Dr. Kiran Reddy","Siva Dinesh","Best Hardware Prototype – TechFest 2025"),
                ("Coding Society","Technical","</>","Programming practice, open source and competitive coding.","Prof. Meera Shah","Priya Nair","Hosted 24-hour CodeRush"),
                ("Dramatics Society","Arts","🎭","Theatre, stage productions, writing and campus performances.","Dr. Kavitha Menon","Rahul Verma","Best Play – University Youth Fest"),
                ("Music Guild","Arts","🎵","A home for vocalists, instrumentalists, composers and performers.","Mr. Joseph Mathew","Ishita Das","Campus Battle of Bands winners"),
                ("E-Cell","Social","🚀","Entrepreneurship, startup mentoring and student pitching.","Dr. Neha Gupta","Aditya Rao","Supported five student startup teams"),
                ("Sports Association","Sports","🏆","Tournaments, fitness and campus team spirit.","Mr. Ramesh","Vikram Singh","Inter-college tournament champions"),
                ("Literary Forum","Arts","📚","Literature, debate, creative writing and spoken word.","Dr. Sneha Iyer","Aditi Sharma","Annual debate league finalists")
            ]
            c.executemany("INSERT INTO clubs(name,category,icon,description,advisor,president,achievements) VALUES(?,?,?,?,?,?,?)", clubs)
            club_rows = c.execute("SELECT id,name FROM clubs").fetchall()
            first = ["Aarav","Diya","Kabir","Ananya","Rohan","Isha","Dev","Meera","Karthik","Nisha","Rahul","Tara","Arjun","Sana","Vivek","Maya","Aditya","Pooja","Siddharth","Kavya","Varun","Ira","Neel","Riya","Manav","Zoya","Ishan","Aanya","Rehan","Tanya"]
            domains = ["student.edu","campus.edu","example.edu"]
            members = []
            for i in range(30):
                cl = club_rows[i % len(club_rows)]
                members.append((first[i], f"{first[i].lower()}{i+1}@{domains[i%3]}", cl["id"], "President" if i in (1,3,5,7) else "Member"))
            c.executemany("INSERT INTO members(name,email,club_id,role) VALUES(?,?,?,?)", members)
            resources = [("Main Audi","Auditorium",500),("Seminar Hall A","Meeting Room",100),("Project Lab 3","Laboratory",40),("Portable Projector","Equipment",1),("PA Sound System","Equipment",1)]
            c.executemany("INSERT INTO resources(name,kind,capacity) VALUES(?,?,?)", resources)
            # Dates are relative to current date so the demo calendar remains populated.
            from datetime import date, timedelta
            today = date.today()
            events = [
                ("Python for Everyone","Introductory hands-on Python workshop",0,"10:00","Seminar Hall A","1"),
                ("AI Robo-Hack 2026","Robotics + Coding Society collaborative hackathon",3,"14:00","Main Audi","2,3"),
                ("Open Mic Evening","Music and spoken word showcase",5,"17:00","Main Audi","5,8"),
                ("Startup Pitch Lab","Pitch your campus startup idea",7,"11:00","Seminar Hall A","6"),
                ("Robot Build Sprint","Build and test a line-following robot",9,"13:00","Project Lab 3","2"),
                ("Stagecraft Workshop","Acting and backstage fundamentals",11,"15:00","Seminar Hall A","4"),
                ("ACM Tech Talk","Industry trends and software careers",13,"12:00","Main Audi","1"),
                ("Campus Football Cup","Inter-department football tournament",15,"09:00","Sports Ground","7"),
                ("Poetry & Prose","Creative writing circle",17,"16:00","Seminar Hall A","8"),
                ("Music Production 101","A beginner studio session",19,"14:00","Music Room","5"),
                ("Founder Stories","Alumni entrepreneur interaction",21,"10:00","Main Audi","6"),
                ("Embedded Systems Lab","Microcontroller practical session",23,"11:00","Project Lab 3","2,1")
            ]
            for title, desc, offset, tm, venue, ids in events:
                c.execute("INSERT INTO events(title,description,event_date,start_time,venue,club_ids) VALUES(?,?,?,?,?,?)",
                          (title,desc,(today+timedelta(days=offset)).isoformat(),tm,venue,ids))

@app.route("/")
def dashboard():
    with db() as c:
        stats = {
            "clubs": c.execute("SELECT COUNT(*) FROM clubs").fetchone()[0],
            "members": c.execute("SELECT COUNT(*) FROM members").fetchone()[0],
            "events": c.execute("SELECT COUNT(*) FROM events WHERE event_date>=date('now','localtime')").fetchone()[0],
            "bookings": c.execute("SELECT COUNT(*) FROM bookings").fetchone()[0]
        }
        events = c.execute("SELECT * FROM events ORDER BY event_date,start_time LIMIT 6").fetchall()
        clubs = c.execute("SELECT * FROM clubs ORDER BY name LIMIT 4").fetchall()
    return render_template("dashboard.html", stats=stats, events=events, clubs=clubs)

@app.route("/clubs")
def clubs():
    q = request.args.get("q","").strip()
    category = request.args.get("category","")
    with db() as c:
        sql = "SELECT * FROM clubs WHERE (name LIKE ? OR description LIKE ?)"
        args = [f"%{q}%",f"%{q}%"]
        if category:
            sql += " AND category=?"; args.append(category)
        sql += " ORDER BY name"
        rows = c.execute(sql,args).fetchall()
    return render_template("clubs.html", clubs=rows, q=q, category=category)

@app.route("/club/<int:club_id>")
def club_detail(club_id):
    with db() as c:
        club = c.execute("SELECT * FROM clubs WHERE id=?",(club_id,)).fetchone()
        if not club: return "Club not found",404
        members = c.execute("SELECT * FROM members WHERE club_id=? ORDER BY role,name",(club_id,)).fetchall()
    return render_template("club_detail.html", club=club, members=members)

@app.post("/join/<int:club_id>")
def join_club(club_id):
    name=request.form.get("name","").strip()
    email=request.form.get("email","").strip().lower()
    if not name or "@" not in email:
        flash("Enter your name and a valid email address.","error")
    else:
        try:
            with db() as c:
                c.execute("INSERT INTO members(name,email,club_id) VALUES(?,?,?)",(name,email,club_id))
            flash("Membership application added successfully!","success")
        except sqlite3.IntegrityError:
            flash("This email is already registered with this club.","error")
    return redirect(url_for("club_detail",club_id=club_id))

@app.route("/bookings", methods=["GET","POST"])
def bookings():
    if request.method=="POST":
        resource_id=request.form.get("resource_id")
        club_id=request.form.get("club_id")
        title=request.form.get("title","").strip()
        day=request.form.get("booking_date")
        start=request.form.get("start_time")
        end=request.form.get("end_time")
        try:
            s=datetime.strptime(f"{day} {start}","%Y-%m-%d %H:%M")
            e=datetime.strptime(f"{day} {end}","%Y-%m-%d %H:%M")
            if e<=s: raise ValueError()
        except (ValueError,TypeError):
            flash("Choose a valid date and an end time later than the start time.","error")
            return redirect(url_for("bookings"))
        with db() as c:
            conflict=c.execute("""
                SELECT b.*,r.name AS resource_name FROM bookings b
                JOIN resources r ON r.id=b.resource_id
                WHERE b.resource_id=? AND b.booking_date=?
                AND b.status!='Rejected'
                AND b.start_time < ? AND b.end_time > ?
            """,(resource_id,day,end,start)).fetchone()
            if conflict:
                flash(f"Facility Already Reserved: {conflict['resource_name']} is booked from {conflict['start_time']} to {conflict['end_time']}. Choose another time.","error")
            else:
                c.execute("INSERT INTO bookings(resource_id,club_id,title,booking_date,start_time,end_time) VALUES(?,?,?,?,?,?)",
                          (resource_id,club_id,title,day,start,end))
                flash("Booking approved! Resource reserved successfully.","success")
        return redirect(url_for("bookings"))
    with db() as c:
        resources=c.execute("SELECT * FROM resources ORDER BY name").fetchall()
        clubs=c.execute("SELECT * FROM clubs ORDER BY name").fetchall()
        rows=c.execute("""SELECT b.*,r.name resource_name,c.name club_name FROM bookings b
                          JOIN resources r ON r.id=b.resource_id JOIN clubs c ON c.id=b.club_id
                          ORDER BY booking_date,start_time""").fetchall()
    return render_template("bookings.html",resources=resources,clubs=clubs,bookings=rows)

@app.route("/events", methods=["GET","POST"])
def events():
    if request.method=="POST":
        title=request.form.get("title","").strip()
        desc=request.form.get("description","").strip()
        day=request.form.get("event_date")
        tm=request.form.get("start_time")
        venue=request.form.get("venue","").strip()
        ids=request.form.getlist("club_ids")
        if not title or not day or not tm or len(ids)<2:
            flash("Enter event details and select at least two co-host clubs.","error")
        else:
            with db() as c:
                c.execute("INSERT INTO events(title,description,event_date,start_time,venue,club_ids) VALUES(?,?,?,?,?,?)",
                          (title,desc,day,tm,venue,",".join(ids)))
            flash("Joint event proposal published to the campus calendar.","success")
        return redirect(url_for("events"))
    with db() as c:
        rows=c.execute("SELECT * FROM events ORDER BY event_date,start_time").fetchall()
        clubs=c.execute("SELECT * FROM clubs ORDER BY name").fetchall()
    return render_template("events.html",events=rows,clubs=clubs)

@app.route("/community", methods=["GET","POST"])
def community():
    if request.method=="POST":
        author=request.form.get("author","").strip()
        body=request.form.get("body","").strip()
        if author and body:
            with db() as c: c.execute("INSERT INTO messages(author,body) VALUES(?,?)",(author,body))
            flash("Message posted.","success")
        return redirect(url_for("community"))
    with db() as c: messages=c.execute("SELECT * FROM messages ORDER BY id DESC LIMIT 50").fetchall()
    return render_template("community.html",messages=messages)

@app.route("/scorecard")
def scorecard():
    with db() as c:
        rows=c.execute("""SELECT c.id,c.name,c.category,c.icon,COUNT(DISTINCT m.id) members,
                          COUNT(DISTINCT e.id) events, c.achievements
                          FROM clubs c LEFT JOIN members m ON m.club_id=c.id
                          LEFT JOIN events e ON instr(','||e.club_ids||',', ','||c.id||',')>0
                          GROUP BY c.id ORDER BY events DESC,members DESC""").fetchall()
    return render_template("scorecard.html",clubs=rows)

@app.route("/api/availability")
def availability():
    resource_id=request.args.get("resource_id")
    day=request.args.get("date")
    with db() as c:
        rows=c.execute("SELECT start_time,end_time,title FROM bookings WHERE resource_id=? AND booking_date=?",(resource_id,day)).fetchall()
    return jsonify([dict(r) for r in rows])

if __name__=="__main__":
    init_db()
    app.run(debug=True,host="127.0.0.1",port=5000)
